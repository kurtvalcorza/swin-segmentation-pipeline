"""SWS review probes (torch-free). Usage: python run_probes.py <repo checkout> <out dir>"""
import json, os, sys, types, re, hashlib, urllib.request
from pathlib import Path
import numpy as np
from PIL import Image

repo, out = Path(sys.argv[1]), Path(sys.argv[2]); out.mkdir(parents=True, exist_ok=True)
NB = repo / 'tutorials/swin_segmentation_colab.ipynb'
nb = json.loads(NB.read_text()); cells = nb['cells']; src = lambda i: ''.join(cells[i]['source'])
sys.path.insert(0, str(repo / 'src'))
import importlib
pkg = types.ModuleType('dimer_swin_segmentation'); pkg.__path__ = [str(repo / 'src/dimer_swin_segmentation')]; sys.modules['dimer_swin_segmentation'] = pkg
M = importlib.import_module('dimer_swin_segmentation.metrics'); SM = importlib.import_module('dimer_swin_segmentation.samples')
assert 'torch' not in sys.modules
R = {}
code = [i for i, c in enumerate(cells) if c['cell_type'] == 'code']
alltext = '\n'.join(src(i) for i in range(len(cells)))
pos = lambda pat: next(i for i in code if pat in src(i))
R['P1_static'] = {'cells': len(cells), 'code_cells': len(code), 'declared': {k: nb['metadata']['dimer'].get(k) for k in ('notebook_profile', 'notebook_mode', 'notebook_spec')},
    'install_cell': pos("'-m', 'pip', 'install'"), 'model_staging_cell': pos('stage_missing_files(WEIGHTS_DIR'), 'python_310_check_cell': pos('sys.version_info[:2] != (3, 10)'),
    'colab_badge_in_cell0': 'colab.research.google.com' in src(0), 'rehead_cell': pos('rehead_model(pipe.model'), 'finetune_cell': pos('pipe.finetune('), 'byod_image_cell': pos('USE_BYOD_IMAGE = False'),
    'ade20k_fixture_digest_checked': 'sha256' in src(pos('USE_ADE20K_FIXTURES')).lower(),
    'cellView_cells': sum(1 for c in cells if c.get('metadata', {}).get('cellView')), 'infrastructure_titles': sum(1 for i in code if '@title' in src(i)),
    'guided_keywords_present': {k: (k.lower() in alltext.lower()) for k in ['How to use this notebook', 'Glossary', 'Roadmap', 'Check your reasoning', 'What to notice', 'Troubleshooting', 'Conclusion', '<details>']},
    'byod_dataset_branch_source': [l for l in src(17).splitlines() if 'USE_BYOD_DATASET' in l or 'BYOD dataset' in l]}
import subprocess
R['P1_static']['recorded_run_blob_32dd1b0_is_this_notebook'] = subprocess.run(['git', '-C', str(repo), 'cat-file', '-e', '40c2cc3:tutorials/swin_segmentation_colab.ipynb'], capture_output=True).returncode == 0

# P2 BYOD dataset branch of cell 17, executed with stand-ins
c17 = src(17).replace('USE_BYOD_DATASET = False', 'USE_BYOD_DATASET = True')
c17 = c17.split('input_manifest = {')[0]  # up to and including validate_dataset
stand = {'synthetic_segmentation_dataset': SM.synthetic_segmentation_dataset, 'validate_dataset': SM.validate_dataset, 'ADAPT_CLASSES': SM.ADAPT_CLASSES, 'DEFAULT_ADAPT_SEED': 20260915}
def run(name, fn):
    try: return {'case': name, 'verdict': 'completed', 'result': fn()}
    except Exception as e: return {'case': name, 'verdict': 'raised', 'error': f'{type(e).__name__}: {e}'[:200]}
def fresh():
    ns = dict(stand); exec(compile(c17, 'cell17', 'exec'), ns); return ns['dataset_summary']['n_records']
def after_default():
    ns = dict(stand); ns['dataset_records'] = SM.synthetic_segmentation_dataset(24, seed=20260915)
    exec(compile(c17, 'cell17', 'exec'), ns); return {'n_records': ns['dataset_summary']['n_records'], 'ids': [r['id'] for r in ns['dataset_records'][:3]], 'note': 'the synthetic records from the earlier run are validated and used as if they were BYOD'}
R['P2_byod_dataset'] = [run('USE_BYOD_DATASET=True in a fresh kernel', fresh), run('USE_BYOD_DATASET=True after a default Run all (re-run from cell 17)', after_default)]

# P3 default adaptation dataset: split, duplicates, baselines, colour rule, label registration
recs = SM.synthetic_segmentation_dataset(24, seed=20260915)
summ = SM.validate_dataset(recs, SM.ADAPT_CLASSES)
tr, va = SM.split_dataset(recs, val_fraction=0.25, seed=42)
dig = lambda r: hashlib.sha256(np.asarray(r['image']).tobytes()).hexdigest()
dups = len({dig(r) for r in tr} & {dig(r) for r in va})
maj = M.majority_class_baseline([r['mask'] for r in va], num_classes=3)
def colour_rule(img):
    a = np.asarray(img).astype(int); r, g, b = a[..., 0], a[..., 1], a[..., 2]
    out = np.zeros(a.shape[:2], np.int64)
    gray = (abs(r - g) < 8) & (abs(g - b) < 8) & (r < 120)
    out[gray] = 1
    reddish = (r > g + 40) & (r > b + 40)
    white = (r > 240) & (g > 240) & (b > 240)
    out[reddish | white] = 2
    return out
cr = M.semantic_iou([colour_rule(r['image']) for r in va], [r['mask'] for r in va], num_classes=3)
test_img, test_mask = SM.generate_scene(99, seed=20260915)
cr_test = M.semantic_iou([colour_rule(test_img)], [test_mask], num_classes=3)
# registration: pixels painted with the structure fill/outline but labelled otherwise, and vice versa
mis = []
for r in recs:
    pred = colour_rule(r['image']); m = r['mask']
    mis.append(int(((pred == 2) != (m == 2)).sum()))
R['P3_default_dataset'] = {'validate': {k: summ[k] for k in ('n_records', 'observed_classes', 'verdict')}, 'split': [len(tr), len(va)], 'val_ids': [r['id'] for r in va],
    'train_val_identical_images': dups, 'majority_baseline_val': maj,
    'colour_rule_val': {k: cr[k] for k in ('miou', 'pixel_accuracy')}, 'colour_rule_unseen_scene_99': {k: cr_test[k] for k in ('miou', 'pixel_accuracy')},
    'structure_pixels_where_colour_and_label_disagree_per_scene': {'min': min(mis), 'max': max(mis), 'mean': round(sum(mis) / len(mis), 1)},
    'note': 'Disagreements come from the 2-px white outline and PIL inclusive rectangle bounds vs exclusive mask slices (generate_scene); the colour rule is a fixed RGB threshold, not learned.'}

# P4 BYOD image branch (cell 15) with stand-ins
c15 = src(15).replace('USE_BYOD_IMAGE = False', 'USE_BYOD_IMAGE = True').split('pretrained_result = pipe.predict')[0]
work = out / 'work'; work.mkdir(exist_ok=True)
def exec15(uploaded=None, colab=True):
    for k in ('google', 'google.colab'): sys.modules.pop(k, None)
    if colab:
        cm = types.ModuleType('google.colab'); g = types.ModuleType('google'); g.colab = cm; cm.files = types.SimpleNamespace(upload=lambda: uploaded)
        sys.modules['google'] = g; sys.modules['google.colab'] = cm
    cwd = os.getcwd(); os.chdir(work)
    try:
        ns = {}; exec(compile(c15, 'cell15', 'exec'), ns); return str(ns['demo_image_path'])
    finally:
        os.chdir(cwd)
R['P4_byod_image'] = [run('cancelled dialog', lambda: exec15({})), run('text file uploaded as photo.jpg', lambda: exec15({'photo.jpg': b'not an image'})), run('outside Colab', lambda: exec15(colab=False)),
    {'has_path_field': bool(re.search(r'BYOD_IMAGE_PATH\s*=', src(15)))}]
for k in ('google', 'google.colab'): sys.modules.pop(k, None)

# P5 wheel availability on the declared-unsupported Python 3.12
def wheels(pkg, ver):
    try:
        d = json.load(urllib.request.urlopen(f'https://pypi.org/pypi/{pkg}/{ver}/json', timeout=30))
        return sorted({u['filename'].split('-')[2] for u in d['urls'] if u['filename'].endswith('.whl')})
    except Exception as e:
        return f'unavailable: {e}'
R['P5_wheels_on_pypi'] = {f'{p}=={v}': wheels(p, v) for p, v in [('torch', '2.1.2'), ('torchvision', '0.16.2'), ('mmsegmentation', '1.2.2')]}
(out / 'results.json').write_text(json.dumps(R, indent=2, default=str))
print(json.dumps(R, indent=1, default=str)[:6000])
